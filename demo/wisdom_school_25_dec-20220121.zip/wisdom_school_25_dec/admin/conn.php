<?php


$conn = mysqli_connect("localhost", "root", "", "wisdom_school") or die("Not connection");
